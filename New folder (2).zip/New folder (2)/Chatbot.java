public class Chatbot {
    static Stack<Integer> stack = new Stack<Integer>();
    public void selectLanguage(){
        Scanner sc= new Scanner(System.in);
        System.out.println("Select the language");
        System.out.println("1.Tamil\n 2.English\n 3.Hindi\n 4.Exit");
        int choose = sc.nextInt();
        switch(choose){
            case 1:
               stack.push(choose);
              System.out.println("you have selected the language tamil");
              break;

            case 2:
              stack.push(choose);
              System.out.println("you have selected the language english");
              break;

            case 3:
              stack.push(choose);
              System.out.println("you have selected the language hindi");
              break;

            case 4:
              System.out.println("exit");
              
              break;
              
            default:
              System.out.println("Invalid data...");
        }
    }
    public void mobileDetails(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Select the details you need to know");
        System.out.println("1.Recharge details\n 2.sim details\n 3.net package details\n 4.exit");
        int choose = sc.nextInt();
        switch(choose){
          case 1:
             System.out.println
        })

    }
    public void mainChoice(){
        do{
        switch(choice.size()){
            case 0:
               selectLanguage();
              break;
            case 1:
               mainMenu();
              break;   
            }
        }while(true);
    }

    public static void main(String[] args){
     Chatbot chat = new Chatbot();
     chat.mainChoice();
    }
    
}
