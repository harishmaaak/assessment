import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Scanner;

public class Register {
    private static ArrayList<Details> studentDetails=new ArrayList<>();
    public void addDetails(Details details)
    {
        studentDetails.add(details);
    }
    public void showDetails()
    {
        for(Details i:studentDetails)
        {
            System.out.println("Name  -->  "+i.getName()+"\nDepartment: --> "+i.getDept()+"\nRegNo --> "+i.getRegNo()+"\n");
        }
    }
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        int choice;
        String tempName;
        Register reg=new Register();
        do {
            System.out.println("Enter your choice\n 1.Enter Details \n 2.View Details \n 3.View Student \n 0.Exit");
            choice=sc.nextInt();
            sc.nextLine();

            switch (choice)
            {
                case 1:
                    System.out.println("Add Details");
                    Details details=new Details();
                    reg.addDetails(details);
                    System.out.println();
                    break;

                case 2:
                    System.out.println("Details of Registered Students");
                    reg.showDetails();
                    System.out.println();
                    break;

                case 3:
                    System.out.println("Enter the name of the trainee:");
                    tempName=sc.nextLine();
                    for(Details i:studentDetails)
                    {
                        if(tempName.equals(i.getName()))
                            System.out.println("Name --> "+i.getName()+"\nDepartment --> "+i.getDept()+"\nRegNo --> "+i.getRegNo());
                    }
                    break;

                case 0:
                    System.out.println("Exiting execution");
                    break;
                default:
                    System.out.println("Wrong Choice");

            }

        }while(choice!=0);

    }

}

class Details implements Serializable
{
    String name;
    String dept;
    long regNo;

    Scanner sc=new Scanner(System.in);
    public String getName() {
        return name;
    }

    public String getDept() {
        return dept;
    }

    public long getRegNo() {
        return regNo;
    }

    public void setName() {
        System.out.println("Enter name:");
        this.name = sc.nextLine();
    }

    public void setDept() {
        System.out.println("Enter Department:");
        this.dept = sc.nextLine();
    }

    public void setRegNo() {
        System.out.println("Enter Regno:");
        this.regNo = sc.nextLong();
    }

    public Details()
    {
        this.setName();
        this.setDept();
        this.setRegNo();
    }
}
    