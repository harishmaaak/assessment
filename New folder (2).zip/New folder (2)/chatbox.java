public class chatbox {
    static Stack<Integer> stack = new Stack<Integer>();
    
    
}
