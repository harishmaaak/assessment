function validate()
{
var username=document.getElementById("username").innerText ;
var password=document.getElementById("password").innerText;
if(username=="admin"&& password=="user")
{
    alert("login successfully");
}
else
{
    alert("login failed");
}

}