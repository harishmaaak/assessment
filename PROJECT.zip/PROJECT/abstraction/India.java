package abstraction;
public abstract class India {
    public void aadhar(){
        System.out.println("Aadhar");
    }
    public void voterId(){
        System.out.println("voter id");
    }

    abstract void culture();
    abstract void food();
}
