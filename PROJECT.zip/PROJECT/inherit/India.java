package inherit;
interface IndianCulture{
    void culture();
}
interface IndianFood{
    void food();
}
public class India implements IndianCulture,IndianFood{
public void culture(){
    System.out.println("Indian culture");
}
public void food(){
    System.out.println("Indian food");
}
}