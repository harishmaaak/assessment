package inherit;

public class Indian {
    public static void main(String[] args){
        India india =  new India();
        india.culture();
        india.food(); 
            
        
    }
    
}
