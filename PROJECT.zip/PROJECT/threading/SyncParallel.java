package threading;
class Sender{
    public void send(String msg){
        System.out.println("sending " + msg);
        try{
            Thread.sleep(1000);
        }catch(Exception e){
            System.out.println("Exeption is catched");
        }
        System.out.println(msg+" sent");
    }
}

class Send extends Thread{
    private String msg;
    Sender sender;
    Send(String m1 , Sender obj){
        msg = m1;
        sender = obj;
    }
    public void run(){
        synchronized(sender){
            sender.send(msg);
        }
    }
}

public class SyncParallel  {

    public static void main(String[] args){
        Sender sent = new Sender();
        Send s1 = new Send("Hi", sent);
        Send s2 = new Send("Bye", sent);
        s1.start();
        s2.start();
        try{
           s1.join();
           s2.join();
        }
        catch(Exception e){
            System.out.println("Exception is catched");
        }
       
    }
    
}
