package threading;

public class Threading implements Runnable {
    public void run(){
        System.out.println("Thread is running");
    }
    public static void main(String[] args){
        Threading threading = new Threading();
        Thread thread = new Thread(threading);
        thread.start();
    }
}
