import java.util.*;

class Duplicate {
    public void removingDuplicate() {
         Scanner sc = new Scanner(System.in);
        // System.out.println("Enter the number of elements : ");
        // int number = sc.nextInt();
        // sc.nextLine();
        // String[] arr = new String[number];
        // System.out.println("Enter the array elements : ");
        // for (int i = 0; i < arr.length; i++) {
        //     arr[i] = sc.nextLine();
        // }
        //System.out.println("Sorted elements");
        //Arrays.sort(arr);
        // for (int i = 0; i < arr.length; i++) {
        //     System.out.println(arr[i]);
        // }
        HashSet<Integer> set=new HashSet<>();
        int n = sc.nextInt();
        for(int i=0;i<n;i++){
            set.add(sc.nextInt());
        }
        for(int s : set){
            set.add(s);
        }
        System.out.println(set);
    }
        public static void main(String[] args){
            Duplicate duplicate = new Duplicate();
            duplicate.removingDuplicate();
        }
    //     System.out.println("Remove Duplicate elements : ");
    //     int count = 0;
    //     for (int i = 0; i < arr.length; i++) {
    //         // for (int j = 1; j < arr.length; j++) {
    //         if (arr[i] == arr[i + 1]) {
    //             count++;
    //             if (count < 2) {
    //                 System.out.println(arr[i]);
    //             }
    //         }
    //     }
    // }
    // }
    // Arrays.sort(arr, 0, arr.length-1);
}
