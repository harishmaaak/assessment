// import java.util.LinkedHashSet;

// public class DuplicatesRemove {
//     public static void main(String[] args){

//         LinkedHashSet<Integer> set = new LinkedHashSet<>();
//         for(int i=0;i<arr.length;i++){

//         }
//     }
    
// }
