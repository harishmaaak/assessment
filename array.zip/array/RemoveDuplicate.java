public class RemoveDuplicate extends Duplicate {
    public static void main(String[] args){
        Duplicate duplicate = new Duplicate();
        duplicate.removingDuplicate();
    }
}
